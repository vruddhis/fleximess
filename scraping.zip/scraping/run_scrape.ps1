# 1. Automatically adapt to the folder wherever this file is cloned
cd $PSScriptRoot

# 2. Set up local relative log file path
$LogFile = ".\scrape_log.txt"
$CurrentTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Content $LogFile "[$CurrentTime] INFO: Starting weekly demo scrape..."

# 3. Teammate edits this line locally with their own DB password
$env:DATABASE_URL = "postgresql://postgres:Govinda%402026@localhost:5432/flexi_mess"

$PythonPath = "python"
$ScraperScript = "scrape_mess.py"

try {
    $Output = & $PythonPath $ScraperScript 2>&1
    Add-Content $LogFile "[$CurrentTime] INFO Done: $Output"
    Write-Host "Scraper finished successfully! Data loaded into database." -ForegroundColor Green
} catch {
    Add-Content $LogFile "[$CurrentTime] ERROR: Execution failed. Details: $_"
    Write-Host "Error running scraper. Check scrape_log.txt" -ForegroundColor Red
    exit 1
}
